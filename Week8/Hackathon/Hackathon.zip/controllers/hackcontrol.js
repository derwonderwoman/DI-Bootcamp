const {
    _getUserFinancialData,
    _getUserPersonalData
  } = require("../models/hackmodels.js");

const getAmount = (req, res) => {
    const { id } = req.params;
    _getUserFinancialData(id)
      .then((data) => {
      res.json(data);
      })
      .catch((e) => {
      res.status(404).json({ msg: "something went wrong" });
      console.log(e);
      });
  };

async function getUserPersonalData(id) {
  try {
    return _getUserPersonalData(id); 
  } 
  catch (error) {
    console.error('Error retrieving user personal data:', error);
    throw error;
    }
};

async function getUserFinancialData(id) {
  try {
    return _getUserFinancialData(id); 
  } 
  catch (error) {
    console.error('Error retrieving user financial data:', error);
    throw error;
  }
}

  module.exports = {
    getAmount,
    getUserPersonalData,
    getUserFinancialData,
  }


